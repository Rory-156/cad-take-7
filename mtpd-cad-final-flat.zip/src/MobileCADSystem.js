import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getFirestore, doc, setDoc, onSnapshot } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyATaceUpM9ELh0yduiMqZHwgXV8sigALfM",
  authDomain: "mtpd-cad-8035b.firebaseapp.com",
  databaseURL: "https://mtpd-cad-8035b-default-rtdb.firebaseio.com",
  projectId: "mtpd-cad-8035b",
  storageBucket: "mtpd-cad-8035b.appspot.com",
  messagingSenderId: "890613447546",
  appId: "1:890613447546:web:459af6a48b0806a021b4c3",
  measurementId: "G-V1TTTWW2CD"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export default function MobileCADSystem() {
  const [unitId, setUnitId] = useState('');
  const [tempUnitId, setTempUnitId] = useState('');
  const [status, setStatus] = useState('Available');
  const [panic, setPanic] = useState(false);
  const [calls, setCalls] = useState([]);
  const [units, setUnits] = useState([]);
  const [newCallDesc, setNewCallDesc] = useState('');
  const [assignUnits, setAssignUnits] = useState({});
  const [panicPlayed, setPanicPlayed] = useState(false);
  const panicTone = new Audio('/Police panic button sound effect.mp3');

  useEffect(() => {
    const unsubUnits = onSnapshot(doc(db, 'shared/units'), (docSnap) => {
      const data = docSnap.data();
      if (data) setUnits(data.list || []);
    });

    const unsubCalls = onSnapshot(doc(db, 'shared/calls'), (docSnap) => {
      const data = docSnap.data();
      if (data) setCalls(data.list || []);
    });

    return () => {
      unsubUnits();
      unsubCalls();
    };
  }, []);

  useEffect(() => {
    if (panic && !panicPlayed) {
      panicTone.play();
      setPanicPlayed(true);
      document.body.classList.add('panic-mode');
      const banner = document.createElement('div');
      banner.id = 'panic-banner';
      const assignedCall = calls.find(call => call.assignedTo === unitId);
      const callInfo = assignedCall ? ` | Incident: ${assignedCall.description}` : '';
      const lastKnown = ` | Last Known Status: ${status}`;
      banner.textContent = `🚨 PANIC MODE ACTIVE - ${unitId} Pressed Panic Button${callInfo}${lastKnown}`;
      banner.style.position = 'fixed';
      banner.style.top = '0';
      banner.style.width = '100%';
      banner.style.backgroundColor = '#b91c1c';
      banner.style.color = 'white';
      banner.style.textAlign = 'center';
      banner.style.padding = '1em';
      banner.style.zIndex = '9999';
      document.body.appendChild(banner);
    } else if (!panic) {
      setPanicPlayed(false);
      document.body.classList.remove('panic-mode');
      const banner = document.getElementById('panic-banner');
      if (banner) document.body.removeChild(banner);
    }
  }, [panic, panicPlayed, calls, status, unitId]);

  const syncUnits = async (updatedUnits) => {
    await setDoc(doc(db, 'shared/units'), { list: updatedUnits });
  };

  const syncCalls = async (updatedCalls) => {
    await setDoc(doc(db, 'shared/calls'), { list: updatedCalls });
  };

  const handleStatusChange = (newStatus) => {
    setStatus(newStatus);
    setPanic(false);
    const updated = units.map((u) =>
      u.id === unitId ? { ...u, status: newStatus } : u
    );
    const exists = updated.some((u) => u.id === unitId);
    const finalList = exists ? updated : [...updated, { id: unitId, status: newStatus }];
    setUnits(finalList);
    syncUnits(finalList);
  };

  const handlePanic = () => {
    setPanic(true);
    setStatus('PANIC - EMERGENCY');
    handleStatusChange('PANIC - EMERGENCY');
  };

  const cancelPanic = () => {
    setPanic(false);
    handleStatusChange('Available');
  };

  const handleLogin = () => {
    setUnitId(tempUnitId);
    const exists = units.find((u) => u.id === tempUnitId);
    if (!exists) {
      const updated = [...units, { id: tempUnitId, status }];
      setUnits(updated);
      syncUnits(updated);
    }
  };

  const handleCreateCall = () => {
    if (!newCallDesc.trim()) return;
    const call = {
      id: Date.now(),
      description: newCallDesc,
      assignedTo: null
    };
    const updated = [call, ...calls];
    setCalls(updated);
    syncCalls(updated);
    setNewCallDesc('');
  };

  const handleAssignCall = (callId) => {
    const unitToAssign = assignUnits[callId];
    if (!unitToAssign) return;
    const updated = calls.map((call) =>
      call.id === callId ? { ...call, assignedTo: unitToAssign } : call
    );
    setCalls(updated);
    syncCalls(updated);
  };

  return (
    <div className={`p-4 max-w-md mx-auto ${panic ? 'animate-pulse bg-red-900 text-white' : ''}`}>
      {!unitId && (
        <div className="space-y-2">
          <input
            placeholder="Enter Unit ID"
            value={tempUnitId}
            onChange={(e) => setTempUnitId(e.target.value)}
          />
          <button onClick={handleLogin}>Login</button>
        </div>
      )}

      {unitId && unitId.toLowerCase() === 'dispatch' && (
        <div className="border rounded p-4 bg-white shadow">
          <h2 className="font-bold mb-2">🚓 Dispatch Panel</h2>
          <textarea
            placeholder="New call description..."
            value={newCallDesc}
            onChange={(e) => setNewCallDesc(e.target.value)}
          />
          <button onClick={handleCreateCall}>Create Call</button>
          {calls.map((call) => (
            <div key={call.id}>
              <p>{call.description}</p>
              <input
                placeholder="Assign unit"
                value={assignUnits[call.id] || ''}
                onChange={(e) =>
                  setAssignUnits({ ...assignUnits, [call.id]: e.target.value })
                }
              />
              <button onClick={() => handleAssignCall(call.id)}>Assign</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
